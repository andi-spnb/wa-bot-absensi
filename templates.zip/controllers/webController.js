const pool = require('../config/database');
const logger = require('../utils/logger');
const moment = require('moment');
const { getSocketStatus } = require('../utils/whatsapp');
const MessageTemplate = require('../models/MessageTemplate');
const BotCommand = require('../models/BotCommand');

// Menampilkan daftar commands
exports.commands = async (req, res) => {
    try {
        const commands = await BotCommand.getAll();
        res.render('commands/index', {
            title: 'Bot Commands',
            commands,
            user: req.session.user,
            success: req.session.success,
            error: null
        });
        // Clear flash message
        delete req.session.success;
    } catch (error) {
        logger.error('Commands error:', error);
        res.render('commands/index', {
            title: 'Bot Commands',
            commands: [],
            user: req.session.user,
            success: null,
            error: 'Failed to load commands'
        });
    }
};

// Menampilkan form create command
exports.createCommand = async (req, res) => {
    res.render('commands/form', {
        title: 'Create Command',
        command: null,
        user: req.session.user,
        error: null
    });
};

// Menyimpan command baru
exports.storeCommand = async (req, res) => {
    try {
        // Tambahkan prefix ! jika belum ada
        let command = req.body.command;
        if (!command.startsWith('!')) {
            command = '!' + command;
        }

        await BotCommand.create({
            ...req.body,
            command
        });

        req.session.success = 'Command created successfully';
        res.redirect('/commands');
    } catch (error) {
        logger.error('Store command error:', error);
        res.render('commands/form', {
            title: 'Create Command',
            command: req.body,
            user: req.session.user,
            error: 'Failed to create command'
        });
    }
};

// Menampilkan form edit
exports.editCommand = async (req, res) => {
    try {
        const command = await BotCommand.findById(req.params.id);
        if (!command) {
            throw new Error('Command not found');
        }

        res.render('commands/form', {
            title: 'Edit Command',
            command,
            user: req.session.user,
            error: null
        });
    } catch (error) {
        logger.error('Edit command error:', error);
        req.session.error = 'Command not found';
        res.redirect('/commands');
    }
};

// Update command
exports.updateCommand = async (req, res) => {
    try {
        // Tambahkan prefix ! jika belum ada
        let command = req.body.command;
        if (!command.startsWith('!')) {
            command = '!' + command;
        }

        await BotCommand.update(req.params.id, {
            ...req.body,
            command
        });

        req.session.success = 'Command updated successfully';
        res.redirect('/commands');
    } catch (error) {
        logger.error('Update command error:', error);
        res.render('commands/form', {
            title: 'Edit Command',
            command: { ...req.body, id: req.params.id },
            user: req.session.user,
            error: 'Failed to update command'
        });
    }
};

// Delete command
exports.deleteCommand = async (req, res) => {
    try {
        await BotCommand.delete(req.params.id);
        res.json({
            success: true,
            message: 'Command deleted successfully'
        });
    } catch (error) {
        logger.error('Delete command error:', error);
        res.status(500).json({
            success: false,
            message: 'Failed to delete command'
        });
    }
};

exports.templates = async (req, res) => {
    try {
        const templates = await MessageTemplate.getAll();
        res.render('templates/index', {
            title: 'Message Templates',
            templates,
            user: req.session.user
        });
    } catch (error) {
        logger.error('Templates error:', error);
        res.render('templates/index', {
            title: 'Message Templates',
            templates: [],
            error: 'Failed to load templates',
            user: req.session.user
        });
    }
};

exports.createTemplate = async (req, res) => {
    res.render('templates/form', {
        title: 'Create Template',
        template: null,
        user: req.session.user
    });
};

exports.storeTemplate = async (req, res) => {
    try {
        await MessageTemplate.create(req.body);
        req.session.success = 'Template created successfully';
        res.redirect('/templates');
    } catch (error) {
        res.render('templates/form', {
            title: 'Create Template',
            template: req.body,
            error: 'Failed to create template',
            user: req.session.user
        });
    }
};

exports.editTemplate = async (req, res) => {
    try {
        const template = await MessageTemplate.findById(req.params.id);
        res.render('templates/form', {
            title: 'Edit Template',
            template,
            user: req.session.user
        });
    } catch (error) {
        res.redirect('/templates');
    }
};

exports.updateTemplate = async (req, res) => {
    try {
        await MessageTemplate.update(req.params.id, req.body);
        req.session.success = 'Template updated successfully';
        res.redirect('/templates');
    } catch (error) {
        res.render('templates/form', {
            title: 'Edit Template',
            template: { ...req.body, id: req.params.id },
            error: 'Failed to update template',
            user: req.session.user
        });
    }
};

exports.deleteTemplate = async (req, res) => {
    try {
        await MessageTemplate.delete(req.params.id);
        res.json({ success: true });
    } catch (error) {
        res.status(500).json({ 
            success: false, 
            message: 'Failed to delete template' 
        });
    }
};

exports.dashboard = async (req, res) => {
    try {
        const whatsappStatus = await getSocketStatus();
        
        const [recentLogs] = await pool.query(
            'SELECT * FROM notification_logs ORDER BY created_at DESC LIMIT 5'
        );

        let stats = {
            total: 0,
            success: 0,
            failed: 0
        };

        const [statsResult] = await pool.query(`
            SELECT 
                COUNT(*) as total,
                SUM(CASE WHEN status = 'success' THEN 1 ELSE 0 END) as success,
                SUM(CASE WHEN status = 'failed' THEN 1 ELSE 0 END) as failed
            FROM notification_logs
        `);

        if (statsResult && statsResult[0]) {
            stats = statsResult[0];
        }

        // Ambil API key aktif
        const [apiKeys] = await pool.query(
            'SELECT api_key FROM api_keys WHERE is_active = true ORDER BY created_at DESC LIMIT 1'
        );

        const apiKey = apiKeys.length > 0 ? apiKeys[0].api_key : '';

        res.render('dashboard/index', {
            title: 'Dashboard',
            whatsappConnected: whatsappStatus.connected,
            recentLogs,
            stats,
            moment,
            apiKey,
            user: req.session.user
        });
    } catch (error) {
        logger.error('Dashboard error:', error);
        res.status(500).render('error', {
            title: 'Error',
            message: error.message,
            user: req.session.user
        });
    }
};

exports.apiKeys = async (req, res) => {
    try {
        const [apiKeys] = await pool.query('SELECT * FROM api_keys ORDER BY created_at DESC');
        res.render('apikeys/index', {
            title: 'API Keys',
            apiKeys,
            user: req.session.user
        });
    } catch (error) {
        logger.error('API Keys error:', error);
        res.render('apikeys/index', {
            title: 'API Keys',
            error: 'Failed to load API keys',
            apiKeys: [],
            user: req.session.user
        });
    }
};

exports.createApiKey = (req, res) => {
    res.render('apikeys/create', {
        title: 'Create API Key'
    });
};

exports.storeApiKey = async (req, res) => {
    const { key_name } = req.body;

    try {
        const apiKey = require('crypto').randomBytes(32).toString('hex');
        await pool.query(
            'INSERT INTO api_keys (key_name, api_key) VALUES (?, ?)',
            [key_name, apiKey]
        );

        req.session.success = 'API key created successfully';
        res.redirect('/api-keys');
    } catch (error) {
        logger.error('Store API key error:', error);
        res.render('apikeys/create', {
            title: 'Create API Key',
            error: 'Failed to create API key',
            key_name
        });
    }
};

exports.deactivateApiKey = async (req, res) => {
    const { id } = req.params;

    try {
        await pool.query(
            'UPDATE api_keys SET is_active = false WHERE id = ?',
            [id]
        );

        res.json({
            success: true,
            message: 'API key deactivated successfully'
        });
    } catch (error) {
        logger.error('Deactivate API key error:', error);
        res.status(500).json({
            success: false,
            message: 'Failed to deactivate API key'
        });
    }
};

exports.logs = async (req, res) => {
    try {
        const page = parseInt(req.query.page) || 1;
        const type = req.query.type || '';
        const limit = 20;
        const offset = (page - 1) * limit;

        let query = 'SELECT * FROM notification_logs';
        let countQuery = 'SELECT COUNT(*) as total FROM notification_logs';
        const queryParams = [];

        if (type) {
            query += ' WHERE type = ?';
            countQuery += ' WHERE type = ?';
            queryParams.push(type);
        }

        query += ' ORDER BY created_at DESC LIMIT ? OFFSET ?';
        queryParams.push(limit, offset);

        const [logs] = await pool.query(query, queryParams);
        const [count] = await pool.query(countQuery, type ? [type] : []);
        const totalPages = Math.ceil(count[0].total / limit);

        res.render('logs/index', {
            title: 'Notification Logs',
            logs,
            currentPage: page,
            totalPages,
            type,
            moment,
            user: req.session.user
        });
    } catch (error) {
        logger.error('Logs error:', error);
        res.render('logs/index', {
            title: 'Notification Logs',
            error: 'Failed to load logs',
            logs: [],
            currentPage: 1,
            totalPages: 1,
            type: '',
            user: req.session.user
        });
    }
};