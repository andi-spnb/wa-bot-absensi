INSERT INTO users (username, password) 
VALUES ('admin', '$2b$10$vJQ8tIhxRVk0J0eTegCwF.6tFLgmOkk3wT5ZZWlbgAhgHVdJIJnI6');
