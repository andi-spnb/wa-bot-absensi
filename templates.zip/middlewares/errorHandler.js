function errorHandler(err, req, res, next) {
    console.error('Error:', err);

    // Check if request is API
    const isApi = req.originalUrl.startsWith('/api');

    if (isApi) {
        // Handle API errors
        return res.status(err.status || 500).json({
            success: false,
            message: err.message || 'Terjadi kesalahan internal server',
            error: process.env.NODE_ENV === 'development' ? err.stack : undefined
        });
    }

    // Handle web errors
    res.status(err.status || 500).render('error', {
        message: err.message || 'Terjadi kesalahan internal server',
        error: process.env.NODE_ENV === 'development' ? err : {}
    });
}

module.exports = errorHandler;