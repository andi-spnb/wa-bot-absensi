// models/BotCommand.js
const pool = require('../config/database');

class BotCommand {
    // Mengambil semua command yang aktif
    static async getAll() {
        const [commands] = await pool.query(
            'SELECT * FROM bot_commands WHERE is_active = true ORDER BY command'
        );
        return commands;
    }

    // Mencari command berdasarkan command name (misal: !help)
    static async findByCommand(command) {
        const [commands] = await pool.query(
            'SELECT * FROM bot_commands WHERE command = ? AND is_active = true',
            [command]
        );
        return commands[0];
    }

    // Membuat command baru
    static async create(data) {
        const { command, title, response, description } = data;
        const [result] = await pool.query(
            'INSERT INTO bot_commands (command, title, response, description) VALUES (?, ?, ?, ?)',
            [command, title, response, description]
        );
        return result.insertId;
    }

    // Update command yang ada
    static async update(id, data) {
        const { command, title, response, description } = data;
        await pool.query(
            'UPDATE bot_commands SET command = ?, title = ?, response = ?, description = ? WHERE id = ?',
            [command, title, response, description, id]
        );
    }

    // Soft delete command (set is_active = false)
    static async delete(id) {
        await pool.query(
            'UPDATE bot_commands SET is_active = false WHERE id = ?',
            [id]
        );
    }

    // Mencari command berdasarkan ID
    static async findById(id) {
        const [commands] = await pool.query(
            'SELECT * FROM bot_commands WHERE id = ?',
            [id]
        );
        return commands[0];
    }
}

module.exports = BotCommand;