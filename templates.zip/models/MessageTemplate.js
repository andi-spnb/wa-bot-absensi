const pool = require('../config/database');

class MessageTemplate {
    static async getAll() {
        const [templates] = await pool.query('SELECT * FROM message_templates ORDER BY name');
        return templates;
    }

    static async create(data) {
        const { name, type, content, variables } = data;
        const [result] = await pool.query(
            'INSERT INTO message_templates (name, type, content, variables) VALUES (?, ?, ?, ?)',
            [name, type, content, JSON.stringify(variables)]
        );
        return result.insertId;
    }

    static async update(id, data) {
        const { name, type, content, variables } = data;
        await pool.query(
            'UPDATE message_templates SET name = ?, type = ?, content = ?, variables = ? WHERE id = ?',
            [name, type, content, JSON.stringify(variables), id]
        );
    }

    static async delete(id) {
        await pool.query('DELETE FROM message_templates WHERE id = ?', [id]);
    }

    static async findById(id) {
        const [templates] = await pool.query('SELECT * FROM message_templates WHERE id = ?', [id]);
        return templates[0];
    }

    static parseTemplate(content, data) {
        return content.replace(/\{\{(\w+)\}\}/g, (match, key) => data[key] || match);
    }
}

module.exports = MessageTemplate;