// Menggunakan Chart.js untuk visualisasi data
function initCharts() {
    // Daily notifications chart
    const dailyCtx = document.getElementById('dailyChart');
    if (dailyCtx) {
        fetch('/api/stats/daily')
            .then(response => response.json())
            .then(data => {
                new Chart(dailyCtx, {
                    type: 'line',
                    data: {
                        labels: data.labels,
                        datasets: [{
                            label: 'Successful',
                            data: data.success,
                            borderColor: '#22c55e',
                            tension: 0.1
                        }, {
                            label: 'Failed',
                            data: data.failed,
                            borderColor: '#ef4444',
                            tension: 0.1
                        }]
                    },
                    options: {
                        responsive: true,
                        plugins: {
                            title: {
                                display: true,
                                text: 'Daily Notifications'
                            }
                        }
                    }
                });
            });
    }

    // Notification types distribution
    const typesCtx = document.getElementById('typesChart');
    if (typesCtx) {
        fetch('/api/stats/types')
            .then(response => response.json())
            .then(data => {
                new Chart(typesCtx, {
                    type: 'doughnut',
                    data: {
                        labels: Object.keys(data),
                        datasets: [{
                            data: Object.values(data),
                            backgroundColor: [
                                '#4f46e5',
                                '#22c55e',
                                '#f59e0b',
                                '#ef4444'
                            ]
                        }]
                    },
                    options: {
                        responsive: true,
                        plugins: {
                            title: {
                                display: true,
                                text: 'Notification Types Distribution'
                            }
                        }
                    }
                });
            });
    }
}

// Initialize charts when page loads
document.addEventListener('DOMContentLoaded', initCharts);