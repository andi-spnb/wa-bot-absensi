// ESM
const { 
  makeWASocket, 
  useMultiFileAuthState, 
  DisconnectReason 
} = require('@whiskeysockets/baileys')
const pino = require('pino')
const qrcode = require('qrcode-terminal')
const logger = require('./logger')

let globalSocket = null

async function startWhatsApp() {
    try {
        const { state, saveCreds } = await useMultiFileAuthState('auth_info_baileys')
        
        const sock = makeWASocket({
            auth: state,
            printQRInTerminal: true,
            browser: ['WA Bot Absensi', '', ''],
            logger: pino({ level: 'silent' })
        })

        sock.ev.on('connection.update', async (update) => {
            const { connection, lastDisconnect, qr } = update
            
            if(qr) {
                logger.info('QR Code ready to scan')
                qrcode.generate(qr, { small: true })
            }

            if(connection === 'close') {
                const shouldReconnect = lastDisconnect?.error?.output?.statusCode !== DisconnectReason.loggedOut
                logger.info('Connection closed due to ', lastDisconnect?.error?.message)
                
                if(shouldReconnect) {
                    startWhatsApp()
                }
            }

            if(connection === 'open') {
                logger.info('WhatsApp connected successfully!')
                globalSocket = sock
            }
        })

        sock.ev.on('messages.upsert', async (m) => {
            const msg = m.messages[0]
            
            if (!msg.key.fromMe && m.type === 'notify') {
                const text = msg.message?.conversation || msg.message?.extendedTextMessage?.text || ''

                if (text.startsWith('!help')) {
                    await sock.sendMessage(msg.key.remoteJid, {
                        text: 'Available commands:\n!help - Show this message\n!status - Check bot status'
                    })
                }
            }
        })

        sock.ev.on('creds.update', saveCreds)

        return sock
    } catch (err) {
        logger.error('Error in WhatsApp setup:', err)
        return null
    }
}

async function sendWhatsAppMessage(to, message) {
    if (!globalSocket) {
        throw new Error('WhatsApp not connected')
    }

    const formattedNumber = to.startsWith('0') ? 
        `62${to.slice(1)}@s.whatsapp.net` : 
        `${to}@s.whatsapp.net`

    await globalSocket.sendMessage(formattedNumber, { text: message })
    return true
}

function getSocketStatus() {
    return {
        connected: globalSocket !== null,
        state: globalSocket ? 'connected' : 'disconnected'
    }
}

module.exports = {
    startWhatsApp,
    sendWhatsAppMessage,
    getSocketStatus
}
